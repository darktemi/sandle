package bitcamp.myapp;

public class AppTest {
  //    @Test public void appHasAGreeting() {
  //        App classUnderTest = new App();
  //        assertNotNull("app should have a greeting", classUnderTest.getGreeting());
  //    }
}
