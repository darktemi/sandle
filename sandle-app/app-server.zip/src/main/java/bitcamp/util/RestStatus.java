package bitcamp.util;

public class RestStatus {
  public static final String SUCCESS = "success";
  public static final String FAILURE = "failure";
}
