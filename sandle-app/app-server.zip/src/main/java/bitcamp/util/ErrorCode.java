package bitcamp.util;

public class ErrorCode {
  public static final class rest {
    public static final String UNAUTHORIZED = "401";
    public static final String NO_DATA = "501";
    public static final String CONTROLLER_EXCEPTION = "601";
  }
}
